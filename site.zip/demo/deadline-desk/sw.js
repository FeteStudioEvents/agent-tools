var C='deadline-desk-demo-v1',F=["./", "index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png", "fonts/Inter-Bold.woff2", "fonts/Inter-Regular.woff2", "fonts/Inter-SemiBold.woff2", "fonts/Lora-Bold.woff2", "img/01_01.jpg", "img/02_01.jpg", "img/03_01.jpg", "img/04_01.jpg", "img/05_01.jpg"];
self.addEventListener('install',function(e){e.waitUntil(caches.open(C).then(function(c){return c.addAll(F);}));self.skipWaiting();});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!==C&&x.indexOf('-demo-')>0;}).map(function(x){return caches.delete(x);}));}));});
self.addEventListener('fetch',function(e){e.respondWith(caches.match(e.request).then(function(r){return r||fetch(e.request);}));});
