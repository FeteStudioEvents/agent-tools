/* Sample data — loaded only by the DEMO build (config demo:true). */
window.TOURDAY_SAMPLE = {
  v: 1, theme: "Navy & Gold", active: "demo1",
  agent: { name: "Jordan Ellis", brokerage: "Harbor & Main Realty Group", phone: "(555) 010-2484" },
  tours: [{
    id: "demo1", name: "Saturday tour · 4 homes", buyers: ["Pat", "Sam"],
    cats: [{ name: "Layout & flow", w: 3 }, { name: "Condition & systems", w: 3 }, { name: "Location & commute fit", w: 2 }, { name: "Natural light", w: 2 },
      { name: "Storage & parking", w: 2 }, { name: "Quiet inside", w: 1 }, { name: "Yard & outdoor space", w: 1 }, { name: "Curb appeal", w: 1 }],
    musts: ["3+ bedrooms", "2+ bathrooms", "Garage or off-street parking"],
    homes: [
      { id: "h1", addr: "123 Example Lane", price: "489000", time: "10:00 AM", scores: { 0: { 0: 5, 1: 4, 2: 4, 3: 5, 4: 4, 5: 4, 6: 3, 7: 4 }, 1: { 0: 4, 1: 4, 2: 5, 3: 4, 4: 4, 5: 3, 6: 4, 7: 4 } },
        must: { 0: true, 1: true, 2: true }, flags: [], cosmetic: "Dated light fixtures", note: "Open kitchen, big windows, short drive to work", photos: "IMG 4410–4431", verdict: { 0: "top", 1: "top" } },
      { id: "h2", addr: "48 Sample Court", price: "472000", time: "11:00 AM", scores: { 0: { 0: 3, 1: 2, 2: 4, 3: 3, 4: 5, 5: 4, 6: 5, 7: 3 }, 1: { 0: 4, 1: 2, 2: 4, 3: 3, 4: 4, 5: 4, 6: 5, 7: 3 } },
        must: { 0: true, 1: true, 2: true }, flags: ["Water stains", "Older HVAC / water heater"], cosmetic: "Great staging", note: "Huge yard; ask inspector about the ceiling stain", photos: "", verdict: { 0: "maybe", 1: "maybe" } },
      { id: "h3", addr: "9 Placeholder Way", price: "505000", time: "12:15 PM", scores: { 0: { 0: 5, 1: 5, 2: 2, 3: 5, 4: 3, 5: 2, 6: 2, 7: 5 }, 1: { 0: 2, 1: 5, 2: 2, 3: 4, 4: 3, 5: 2, 6: 2, 7: 5 } },
        must: { 0: true, 1: true, 2: false }, flags: [], cosmetic: "", note: "Beautiful but street parking only", photos: "", verdict: { 0: "top", 1: "no" } },
      { id: "h4", addr: "77 Demo Drive", price: "468000", time: "1:30 PM", scores: { 0: { 0: 3, 1: 4, 2: 3, 3: 3, 4: 4, 5: 5, 6: 3, 7: 3 }, 1: { 0: 4, 1: 4, 2: 3, 3: 3, 4: 4, 5: 5, 6: 3, 7: 2 } },
        must: { 0: true, 1: true, 2: true }, flags: ["Doors / windows stick"], cosmetic: "Needs paint", note: "Quiet street, smaller kitchen", photos: "", verdict: { 0: "maybe", 1: "maybe" } }
    ]
  }]
};
