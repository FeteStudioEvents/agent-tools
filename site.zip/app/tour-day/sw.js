/* Tour Day service worker: cache-first so the app works with no signal. */
var CACHE = "tourday-v8";  // bump on every release so installed phones get fixes
var FILES = ["./", "index.html", "style.css", "app.js", "config.js", "sample.js", "manifest.webmanifest", "icon-192.png", "icon-512.png",
  "fonts/Inter-Regular.woff2", "fonts/Inter-SemiBold.woff2", "fonts/Inter-Bold.woff2", "fonts/Lora-Bold.woff2"];
self.addEventListener("install", function (e) { e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(FILES); })); self.skipWaiting(); });
self.addEventListener("activate", function (e) {
  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })); }));
  self.clients.claim();
});
self.addEventListener("fetch", function (e) {
  if (e.request.method !== "GET") return;
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then(function (r) {
    return r || fetch(e.request).then(function (res) {
      var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(e.request, copy); }); return res;
    }).catch(function () { return caches.match("index.html"); });
  }));
});
