/* Tour Day · Home Score Card — Fête Studio. Offline, no account, data stays in this browser (localStorage). */
(function () {
  "use strict";
  var CFG = window.TOURDAY_CONFIG || { demo: false };
  var KEY = CFG.demo ? "tourday-demo-v1" : "tourday-v1";
  var THEMES = ["Navy & Gold", "Sage & Linen", "Blush & Mauve", "Charcoal & Copper"];
  var DEFAULT_CATS = [
    { name: "Layout & flow", w: 3 }, { name: "Condition & systems", w: 3 }, { name: "Location & commute fit", w: 2 },
    { name: "Natural light", w: 2 }, { name: "Storage & parking", w: 2 }, { name: "Quiet inside", w: 1 },
    { name: "Yard & outdoor space", w: 1 }, { name: "Curb appeal", w: 1 }];
  var FLAGS = ["Water stains", "Foundation / wall cracks", "Roof looks worn", "Older HVAC / water heater", "Musty smell",
    "Electrical panel questions", "Doors / windows stick", "Slope or drainage", "Other (see note)"];
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var view = $("#view");
  var S = load();
  var route = { name: "homes", id: null };
  var who = 0;

  function uid() { return Math.random().toString(36).slice(2, 9); }
  function blankTour(name) {
    return { id: uid(), name: name || "Saturday tour", buyers: ["Buyer 1", "Buyer 2"], cats: JSON.parse(JSON.stringify(DEFAULT_CATS)),
      musts: ["3+ bedrooms", "2+ bathrooms", "Garage or off-street parking"], homes: [] };
  }
  function load() {
    try { var s = JSON.parse(localStorage.getItem(KEY)); if (s && s.tours) return migrate(s); } catch (e) {}
    var st = { v: 1, agent: { name: "", brokerage: "", phone: "" }, theme: THEMES[0], tours: [], active: null };
    if (CFG.demo && window.TOURDAY_SAMPLE) { st = JSON.parse(JSON.stringify(window.TOURDAY_SAMPLE)); }
    if (!st.tours.length) { var t = blankTour(); st.tours.push(t); st.active = t.id; }
    return migrate(st);
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { toast("Couldn't save — storage is full or blocked"); } }
  function tour() { return S.tours.filter(function (t) { return t.id === S.active; })[0] || S.tours[0]; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function money(n) { n = Number(String(n || "").replace(/[^0-9.]/g, "")); return n ? "$" + Math.round(n).toLocaleString("en-US") : ""; }
  function toast(m) { var t = $("#toast"); t.textContent = m; t.classList.add("show"); clearTimeout(toast.h); toast.h = setTimeout(function () { t.classList.remove("show"); }, 2200); }

  // ---------- scoring ----------
  function catAvg(h, ci) {
    var v = [], i; for (i = 0; i < 2; i++) { var x = h.scores && h.scores[i] && h.scores[i][ci]; if (x) v.push(x); }
    return v.length ? v.reduce(function (a, b) { return a + b; }, 0) / v.length : null;
  }
  function score(h, t, only) {
    var sw = 0, s = 0;
    t.cats.forEach(function (c, ci) {
      if (!c.w) return;
      var a = only == null ? catAvg(h, ci) : (h.scores && h.scores[only] && h.scores[only][ci]) || null;
      if (a) { s += a * c.w; sw += c.w; }
    });
    return sw ? Math.round(((s / sw) - 1) / 4 * 100) : null;
  }
  function mv(h, m) { return h.must ? h.must[m] : undefined; }
  function mustMiss(h, t) { return t.musts.filter(function (m) { return mv(h, m) === false; }); }
  function mustMet(h, t) { return t.musts.filter(function (m) { return mv(h, m) === true; }).length; }
  function mustAnswered(h, t) { return t.musts.filter(function (m) { return mv(h, m) !== undefined && mv(h, m) !== null; }).length; }
  function migrate(st) {   // v1 stored must-have answers by position; v2 by text
    (st.tours || []).forEach(function (t) { t.homes.forEach(function (h, i) {
      if (h.must && Object.keys(h.must).some(function (k) { return /^\d+$/.test(k); })) {
        var m2 = {}; Object.keys(h.must).forEach(function (k) { if (/^\d+$/.test(k) && t.musts[+k] != null) m2[t.musts[+k]] = h.must[k]; else m2[k] = h.must[k]; }); h.must = m2;
      }
      if (!h.n) h.n = i + 1;
    }); });
    return st;
  }
  function talk(h, t) {
    var out = [];
    t.cats.forEach(function (c, ci) {
      var a = h.scores && h.scores[0] && h.scores[0][ci], b = h.scores && h.scores[1] && h.scores[1][ci];
      if (a && b && Math.abs(a - b) >= 2) out.push(c.name + " (" + t.buyers[0] + " " + a + ", " + t.buyers[1] + " " + b + ")");
    });
    return out;
  }
  function ranked(t) {
    return t.homes.slice().sort(function (x, y) {
      var mx = mustMiss(x, t).length ? 1 : 0, my = mustMiss(y, t).length ? 1 : 0;
      if (mx !== my) return mx - my;
      return (score(y, t) || -1) - (score(x, t) || -1);
    });
  }
  function verdictBadges(h, t) {
    var out = "";
    [0, 1].forEach(function (i) {
      var v = h.verdict && h.verdict[i];
      if (v) out += '<span class="badge b-' + v + '">' + esc(t.buyers[i]) + ": " + { top: "Top", maybe: "Maybe", no: "No" }[v] + "</span>";
    });
    return out;
  }

  // ---------- views ----------
  function setHeader(kicker, title, back) {
    $("#kicker").textContent = kicker; $("#title").textContent = title; $("#back").hidden = !back;
    document.querySelectorAll("#tabs button").forEach(function (b) { b.classList.toggle("on", b.dataset.go === route.name); });
  }
  function go(name, id) { route = { name: name, id: id || null }; try { sessionStorage.setItem(KEY + "-route", JSON.stringify(route)); } catch (e) {} render(); window.scrollTo(0, 0); }

  function render() {
    document.body.dataset.theme = S.theme;
    var t = tour();
    var fn = { homes: vHomes, home: vHome, compare: vCompare, share: vShare, settings: vSettings, setup: vSetup, imp: vImport }[route.name] || vHomes;
    fn(t);
  }

  function named(t) { return !(t.buyers[0] === "Buyer 1" && t.buyers[1] === "Buyer 2"); }
  function brandLine() {
    var a = S.agent || {};
    if (!a.name && !a.brokerage) return '<div class="brand">Fête Studio · Tour Day</div>';
    return '<div class="brand"><b>' + esc(a.name) + "</b>" + (a.brokerage ? " · <b>" + esc(a.brokerage) + "</b>" : "") + (a.phone ? ' · <span style="white-space:nowrap">' + esc(a.phone) + "</span>" : "") + "</div>";
  }

  function vHomes(t) {
    setHeader(named(t) ? t.buyers.join(" & ") : "Tour Day", t.name, false);
    var h = "";
    if (!t.homes.length) {
      h += '<div class="card empty"><h2>Ready for tour day</h2><p class="hint">Add the homes you\'ll see, in showing order. At each home, tap a score for each category — it takes about a minute.</p></div>';
    }
    t.homes.forEach(function (x, i) {
      var sc = score(x, t), miss = mustMiss(x, t), fl = (x.flags || []).length;
      h += '<div class="card home" data-open="' + x.id + '"><div class="n">' + x.n + '</div><div class="meta"><div class="addr">' + esc(label(x)) + "</div>" +
        '<div class="sub">' + [money(x.price), x.time].filter(Boolean).map(esc).join(" · ") + "</div>" +
        (miss.length ? '<span class="badge b-bad">Misses a must-have</span>' : "") + (fl ? '<span class="badge b-warn">' + fl + " for the inspector</span>" : "") + verdictBadges(x, t) +
        '</div><div class="score">' + (sc == null ? "–" : sc) + "<small>/100</small></div></div>";
    });
    if (installEvt && !standalone()) h += '<button class="btn gold" id="install">Install Tour Day on this phone</button>';
    h += '<button class="btn" id="add">+ Add a home</button>';
    h += '<button class="btn alt" id="setup">Tour setup: names, must-haves, what matters</button>';
    h += brandLine();
    view.innerHTML = h;
    view.querySelectorAll("[data-open]").forEach(function (el) { el.onclick = function () { go("home", el.dataset.open); }; });
    $("#add").onclick = function () { addHome(t); };
    $("#setup").onclick = function () { go("setup"); };
    if ($("#install")) $("#install").onclick = function () { installEvt.prompt(); installEvt.userChoice.then(function () { installEvt = null; render(); }); };
  }

  function addHome(t) {
    var n = t.homes.reduce(function (m, h) { return Math.max(m, h.n || 0); }, 0) + 1;
    var x = { id: uid(), n: n, addr: "", price: "", time: "", scores: {}, must: {}, flags: [], verdict: {} }; t.homes.push(x); save(); go("home", x.id);
  }
  var lastHome = null;
  function label(x) { return x.addr || "Home " + x.n; }
  function vHome(t) {
    var x = t.homes.filter(function (h) { return h.id === route.id; })[0];
    if (!x) return go("homes");
    var idx = t.homes.indexOf(x) + 1;
    if (lastHome !== x.id) { who = 0; lastHome = x.id; }
    setHeader("Home " + x.n + " · " + idx + " of " + t.homes.length, x.addr || "New home", true);
    var other = who === 0 ? 1 : 0;
    var h = '<div class="card"><label class="f" for="addr">Address or MLS #</label><input id="addr" value="' + esc(x.addr) + '" placeholder="e.g. 123 Example Lane" autocomplete="off">' +
      '<div class="row2"><div><label class="f" for="price">List price</label><input id="price" inputmode="numeric" value="' + esc(x.price) + '" placeholder="$"></div>' +
      '<div><label class="f" for="time">Showing time</label><input id="time" value="' + esc(x.time) + '" placeholder="10:30 AM"></div></div>' +
      '<p class="hint" style="margin-top:10px">📷 Photo tip: snap the house number first, then the rooms — your photos stay in order.</p></div>';
    h += '<div class="who" role="tablist">' + t.buyers.map(function (b, i) { return '<button role="tab" aria-selected="' + (i === who) + '" data-who="' + i + '" class="' + (i === who ? "on" : "") + '">' + esc(b) + " scores</button>"; }).join("") + "</div>";
    h += '<div class="card"><h3 style="margin-top:0">Score this home · 1 = poor, 5 = great</h3>';
    t.cats.forEach(function (c, ci) {
      if (!c.w) return;
      var mine = x.scores[who] && x.scores[who][ci], theirs = x.scores[other] && x.scores[other][ci];
      h += '<div class="cat"><div class="lab">' + esc(c.name) + (theirs ? "<small>" + esc(t.buyers[other]) + ": " + theirs + "</small>" : "") + '</div><div class="pips">';
      for (var v = 1; v <= 5; v++) h += '<button data-cat="' + ci + '" data-v="' + v + '" class="' + (mine === v ? "on" : "") + (theirs === v ? " other" : "") + '" aria-label="' + esc(c.name) + " " + v + '">' + v + "</button>";
      h += '</div></div>';
    });
    h += '<div class="scale"><span>1 poor</span><span>3 fine</span><span>5 great</span></div></div>';
    if (t.musts.length) {
      h += '<div class="card"><h3 style="margin-top:0">Must-haves</h3>';
      t.musts.forEach(function (m, i) {
        var v = mv(x, m);
        h += '<div class="yn"><div class="t">' + esc(m) + '</div><button class="y ' + (v === true ? "on" : "") + '" data-must="' + i + '" data-val="1">Yes</button><button class="n ' + (v === false ? "on" : "") + '" data-must="' + i + '" data-val="0">No</button></div>';
      });
      h += "</div>";
    }
    h += '<div class="card"><h3 style="margin-top:0">Notice anything for the inspector?</h3><div class="chips">' +
      FLAGS.map(function (f) { return '<button data-flag="' + esc(f) + '" class="' + ((x.flags || []).indexOf(f) > -1 ? "on" : "") + '">' + esc(f) + "</button>"; }).join("") + "</div>" +
      '<p class="hint" style="margin-top:10px">Not a diagnosis — just a list to ask the inspector about.</p></div>';
    h += '<div class="card"><h3 style="margin-top:0">Cosmetic only (not scored)</h3><input id="cos" value="' + esc(x.cosmetic) + '" placeholder="Paint, staging, light fixtures…">' +
      '<label class="f" for="note">One-line note</label><textarea id="note" placeholder="What will you remember about this home?">' + esc(x.note) + "</textarea>" +
      '<label class="f" for="photos">Photo numbers (optional)</label><input id="photos" value="' + esc(x.photos) + '" placeholder="e.g. IMG 4410–4432">' +
      '<div class="fair">Describe the home, not people or neighbors. For schools or area info, look up official sources.</div></div>';
    var vd = x.verdict[who];
    h += '<div class="card"><h3 style="margin-top:0">' + esc(t.buyers[who]) + "'s gut feeling</h3><div class=\"verdict\">" +
      ["top", "maybe", "no"].map(function (k) { return '<button data-verdict="' + k + '" class="' + k + (vd === k ? " on" : "") + '">' + { top: "Top", maybe: "Maybe", no: "No" }[k] + "</button>"; }).join("") + "</div></div>";
    var sc = score(x, t);
    var rated = t.cats.filter(function (c, ci) { return c.w && catAvg(x, ci); }).length, active = t.cats.filter(function (c) { return c.w; }).length;
    h += '<div class="card" style="text-align:center"><div class="pill">Score so far · <span id="rated">' + rated + " of " + active + ' rated</span></div><div style="font:700 34px Lora,serif;color:var(--p)">' + (sc == null ? "–" : sc) + '<span style="font-size:15px">/100</span></div></div>';
    var nextH = t.homes[idx];
    h += nextH ? '<button class="btn" id="next">Next home ›</button>' : '<button class="btn" id="addNext">+ Add the next home</button><button class="btn alt" id="next">See the comparison ›</button>';
    h += '<button class="btn alt" id="del" style="border-color:#B9B2A5;color:#6a645a">Remove this home</button>';
    view.innerHTML = h;
    function bind(id, key) { var el = $("#" + id); el.oninput = function () { x[key] = el.value; save(); if (key === "addr") $("#title").textContent = el.value || "New home"; }; }
    bind("addr", "addr"); bind("price", "price"); bind("time", "time"); bind("cos", "cosmetic"); bind("note", "note"); bind("photos", "photos");
    view.querySelectorAll("[data-who]").forEach(function (b) { b.onclick = function () { who = +b.dataset.who; vHome(t); }; });
    view.querySelectorAll("[data-cat]").forEach(function (b) {
      b.onclick = function () {
        var ci = +b.dataset.cat, v = +b.dataset.v;
        x.scores[who] = x.scores[who] || {};
        x.scores[who][ci] = v;
        save();
        var row = b.parentNode; row.querySelectorAll("button").forEach(function (o) { o.classList.toggle("on", +o.dataset.v === x.scores[who][ci]); });
        var s = score(x, t); view.querySelector('[style*="34px"]').innerHTML = (s == null ? "–" : s) + '<span style="font-size:15px">/100</span>';
        $("#rated").textContent = t.cats.filter(function (c, k) { return c.w && catAvg(x, k); }).length + " of " + t.cats.filter(function (c) { return c.w; }).length + " rated";
      };
    });
    view.querySelectorAll("[data-must]").forEach(function (b) {
      b.onclick = function () { var m = t.musts[+b.dataset.must], v = b.dataset.val === "1"; x.must = x.must || {}; x.must[m] = v; save(); vHomeKeep(t); };
    });
    view.querySelectorAll("[data-flag]").forEach(function (b) {
      b.onclick = function () { var f = b.dataset.flag, a = x.flags || (x.flags = []), i = a.indexOf(f); if (i > -1) a.splice(i, 1); else a.push(f); save(); b.classList.toggle("on"); };
    });
    view.querySelectorAll("[data-verdict]").forEach(function (b) {
      b.onclick = function () { x.verdict[who] = b.dataset.verdict; save(); vHomeKeep(t); };
    });
    $("#next").onclick = function () { if (nextH) go("home", nextH.id); else go("compare"); };
    if ($("#addNext")) $("#addNext").onclick = function () { addHome(t); };
    $("#del").onclick = function () { if (confirm("Remove this home from the tour?")) { t.homes.splice(t.homes.indexOf(x), 1); save(); go("homes"); } };
  }
  function vHomeKeep(t) { var y = window.scrollY; vHome(t); window.scrollTo(0, y); }

  function vCompare(t) {
    setHeader(t.buyers.join(" & "), "Compare", false);
    var r = ranked(t), h = "";
    if (!r.length) { view.innerHTML = '<div class="card empty">Add and score a few homes first.</div><button class="btn" id="add">+ Add your first home</button>' + brandLine(); $("#add").onclick = function () { addHome(t); }; return; }
    h += '<p class="hint">Ranked by what matters to you (set in Tour setup). Homes that miss a must-have drop to the bottom.</p>';
    r.forEach(function (x, i) {
      var sc = score(x, t), miss = mustMiss(x, t), tk = talk(x, t), a = score(x, t, 0), b = score(x, t, 1);
      h += '<div class="card rank" data-open="' + x.id + '"><div class="pos">' + (i + 1) + '</div><div style="flex:1;min-width:0"><div class="addr" style="font-weight:700">' + esc(label(x)) + "</div>" +
        '<div class="sub pill">' + [money(x.price), t.musts.length ? (mustAnswered(x, t) ? mustMet(x, t) + " yes" + (mustMiss(x, t).length ? " · " + mustMiss(x, t).length + " no" : "") + (t.musts.length - mustAnswered(x, t) ? " · " + (t.musts.length - mustAnswered(x, t)) + " not checked" : "") + " (must-haves)" : "must-haves not checked yet") : ""].filter(Boolean).join(" · ") + "</div>" +
        '<div class="bar"><i style="width:' + (sc || 0) + '%"></i></div>' +
        '<div class="pill">' + (sc == null ? "Not scored yet" : "Score " + sc + "/100") + (a != null && b != null ? " · " + esc(t.buyers[0]) + " " + a + " · " + esc(t.buyers[1]) + " " + b : "") + "</div>" +
        (miss.length ? '<span class="badge b-bad">Misses: ' + esc(miss.join(", ")) + "</span>" : "") +
        ((x.flags || []).length ? '<span class="badge b-warn">Ask inspector: ' + esc(x.flags.join(", ")) + "</span>" : "") + verdictBadges(x, t) +
        (tk.length ? '<div class="talk">Talk about: ' + esc(tk.join("; ")) + "</div>" : "") +
        (x.note ? '<div class="pill" style="margin-top:4px">“' + esc(x.note) + "”</div>" : "") + "</div></div>";
    });
    h += '<button class="btn gold" id="toShare">Send results to my agent ›</button><button class="btn alt noprint" id="print">Print / save as PDF</button>' + brandLine();
    view.innerHTML = h;
    view.querySelectorAll("[data-open]").forEach(function (el) { el.onclick = function () { go("home", el.dataset.open); }; });
    $("#toShare").onclick = function () { go("share"); };
    $("#print").onclick = function () { window.print(); };
  }

  function parseBulk(text) {
    return String(text || "").split(/\r?\n/).map(function (line) {
      var parts = line.split(/\t|\s*\|\s*/).map(function (p) { return p.trim(); }).filter(function (p) { return p !== ""; });
      if (!parts.length) return null;
      var time = "", price = "", addr = "";
      parts.forEach(function (p) {
        if (!time && /^\d{1,2}(:\d{2})?\s*(am|pm)?$/i.test(p)) time = p;
        else if (!price && /^\$?[\d,]{4,}(\.\d+)?$/.test(p)) price = p.replace(/[^0-9.]/g, "");
        else if (!addr) addr = p;
      });
      return addr ? { time: time, addr: addr.slice(0, 120), price: price } : null;
    }).filter(Boolean).slice(0, 30);
  }

  // ---------- share / import ----------
  function b64e(str) { var bytes = new TextEncoder().encode(str), bin = ""; bytes.forEach(function (b) { bin += String.fromCharCode(b); }); return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
  function b64d(s) { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new TextDecoder().decode(u); }
  function shareLink(t) { return location.origin + location.pathname + "#t=" + b64e(JSON.stringify({ v: 1, tour: t, from: S.agent })); }
  function summaryText(t) {
    var lines = [t.name + " — " + t.buyers.join(" & ")];
    ranked(t).forEach(function (x, i) {
      var sc = score(x, t), miss = mustMiss(x, t);
      lines.push((i + 1) + ". " + label(x) + (x.price ? " (" + money(x.price) + ")" : "") + " — " + (sc == null ? "not scored" : sc + "/100") +
        (miss.length ? " · misses: " + miss.join(", ") : "") + ((x.flags || []).length ? " · ask inspector: " + x.flags.join(", ") : "") + (x.note ? " · “" + x.note + "”" : ""));
    });
    var a = S.agent || {};
    if (a.name || a.brokerage) lines.push("— " + [a.name, a.brokerage, a.phone].filter(Boolean).join(" · "));
    return lines.join("\n");
  }
  function cellSafe(v) { v = String(v == null ? "" : v).replace(/[\t\n]/g, " "); return /^[=+\-@]/.test(v) ? "'" + v : v; }
  function tsv(t) {
    var head = ["Tour", "Home #", "Address", "List price", "Scored by"].concat(t.cats.map(function (c) { return c.name; })).concat(["Must-haves met", "Must-haves missed", "Ask inspector", "Gut feeling", "Note"]);
    var rows = [head.join("\t")];
    t.homes.forEach(function (x, i) {
      [0, 1].forEach(function (w) {
        var s = x.scores[w]; if (!s || !Object.keys(s).some(function (k) { return s[k]; })) return;
        rows.push([cellSafe(t.name), x.n, cellSafe(label(x)), String(x.price || "").replace(/[^0-9.]/g, ""), cellSafe(t.buyers[w])].concat(t.cats.map(function (c, ci) { return s[ci] || ""; }))
          .concat([mustMet(x, t) + " of " + t.musts.length, cellSafe(mustMiss(x, t).join(", ")), cellSafe((x.flags || []).join(", ")), (x.verdict && x.verdict[w]) || "", cellSafe(x.note)]).join("\t"));
      });
    });
    return rows.join("\n");
  }
  function copy(text, msg) {
    function fallback() { var ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); toast(msg); } catch (e) { toast("Select and copy the text below"); } ta.remove(); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { toast(msg); }, fallback); else fallback();
  }
  function vShare(t) {
    setHeader(t.buyers.join(" & "), "Share", false);
    var h = '<div class="card"><h2>Send to your agent or partner</h2><p class="hint">The scores travel inside the link itself — nothing is uploaded. Anyone with this link can see these scores, so send it only to your agent or partner.</p>' +
      '<button class="btn" id="shareLink">Share link (text or email)</button><button class="btn alt" id="copyLink">Copy link</button></div>' +
      '<div class="card"><h2>Quick summary</h2><p class="hint">Ranked list as plain text.</p><button class="btn alt" id="copySum">Copy summary</button></div>' +
      '<details class="card"><summary style="font:700 17px Lora,serif;color:var(--p);cursor:pointer;min-height:32px">For your agent: spreadsheet rows ›</summary><p class="hint">Do this on the computer that has your Tour Day sheet: open the buyer\'s link there, tap <b>Add to my tours</b>, then copy. In the sheet: <b>Phone Scores</b> tab › select rows 6–85 › Delete › click cell <b>A5</b> › paste.</p>' +
      '<button class="btn alt" id="copyTsv">Copy rows for Google Sheets / Excel</button><pre class="tsv">' + esc(tsv(t)) + "</pre></details>" + brandLine();
    view.innerHTML = h;
    $("#shareLink").onclick = function () {
      var url = shareLink(t), text = "Tour Day scores: " + t.name;
      if (navigator.share) navigator.share({ title: "Tour Day scores", text: text, url: url }).catch(function () {}); else copy(url, "Link copied — paste it into a text or email");
    };
    $("#copyLink").onclick = function () { copy(shareLink(t), "Link copied"); };
    $("#copySum").onclick = function () { copy(summaryText(t), "Summary copied"); };
    $("#copyTsv").onclick = function () { copy(tsv(t), "Rows copied — paste into Phone Scores, cell A5"); };
  }
  var pending = null;
  function scored(t) { return t.homes.some(function (h) { return h.scores && Object.keys(h.scores).some(function (w) { return h.scores[w] && Object.keys(h.scores[w]).some(function (k) { return h.scores[w][k]; }); }); }); }
  function vImport() {
    setHeader("Tour Day", pending && pending.tour && !scored(pending.tour) ? "Your tour" : "Shared scores", true);
    if (!pending) return go("homes");
    var t = pending.tour;
    var fromName = pending.from && pending.from.name ? esc(pending.from.name) : "";
    var fresh = !scored(t);
    view.innerHTML = '<div class="card"><h2>' + (!fresh ? esc(t.name) : "Your tour" + (fromName ? " from " + fromName : "")) + '</h2><p class="hint">' +
      (!fresh ? esc(t.buyers.join(" & ")) + " · " + t.homes.length + " homes" + (fromName ? " · from " + fromName : "")
                      : "Your agent set up what matters to you. At each home, tap a score for each category — about a minute per home.") +
      (fresh && t.homes.length ? " " + t.homes.length + " homes are ready for you." : "") +
      '</p><button class="btn" id="imp">' + (!fresh ? "Add to my tours" : "Start my tour") + '</button><button class="btn alt" id="cancel">Not now</button></div>';
    $("#imp").onclick = function () {
      migrate({ tours: [t] });
      var sig = function (x) { return x.name + "|" + x.homes.map(function (h) { return h.addr; }).join("|"); };
      var dup = S.tours.filter(function (x) { return x.homes.length > 0 && sig(x) === sig(t); })[0];
      if (dup && !confirm("You already added this tour. Replace it with these scores?")) { pending = null; history.replaceState(null, "", location.pathname); S.active = dup.id; save(); go("compare"); return; }
      if (dup) S.tours.splice(S.tours.indexOf(dup), 1);
      S.tours = S.tours.filter(function (x) { return x.homes.length > 0; });   // drop empty starter tours
      t.id = uid(); S.tours.push(t); S.active = t.id;
      var a = S.agent || (S.agent = {}), f = pending.from || {};
      if (!a.name && !a.brokerage && (f.name || f.brokerage)) { a.name = f.name || ""; a.brokerage = f.brokerage || ""; a.phone = f.phone || ""; }
      save(); pending = null; history.replaceState(null, "", location.pathname); toast("Tour added"); go(scored(t) ? "compare" : "homes");
    };
    $("#cancel").onclick = function () { pending = null; history.replaceState(null, "", location.pathname); go("homes"); };
  }

  // ---------- setup & settings ----------
  function vSetup(t) {
    setHeader("Tour setup", t.name, true);
    var h = '<div class="card"><label class="f" for="tname">Tour name</label><input id="tname" value="' + esc(t.name) + '">' +
      '<div class="row2"><div><label class="f" for="b0">Person 1</label><input id="b0" value="' + esc(t.buyers[0]) + '"></div><div><label class="f" for="b1">Person 2</label><input id="b1" value="' + esc(t.buyers[1]) + '"></div></div>' +
      '<p class="hint">Two people can score each home separately. Solo? Leave Person 2 as is and ignore it.</p></div>';
    h += '<div class="card"><h3 style="margin-top:0">Add homes from a list</h3><p class="hint">Paste from the Tour Day sheet (Tour Schedule › Copy for the app) or type one home per line: <b>time | address | price</b>.</p>' +
      '<textarea id="bulk" rows="4" aria-label="Homes to add, one per line" placeholder="10:00 AM | 123 Example Lane | 489000"></textarea><button class="btn alt" id="bulkAdd">Add these homes</button></div>';
    h += '<div class="card"><h3 style="margin-top:0">Must-haves (pass / fail)</h3><p class="hint">One per line. A home that misses one drops to the bottom of the ranking.</p><textarea id="musts" rows="4" aria-label="Must-haves, one per line">' + esc(t.musts.join("\n")) + "</textarea></div>";
    h += '<div class="card"><h3 style="margin-top:0">What matters most?</h3><p class="hint">Stars = how much each category counts (0 = skip it). Rename any category. Agents: set this up on your phone, then Share the tour link with your buyers so they get the same setup.</p>';
    t.cats.forEach(function (c, ci) {
      h += '<div class="wrow"><input data-cname="' + ci + '" aria-label="Category ' + (ci + 1) + ' name" value="' + esc(c.name) + '"><span class="stars">' + [1, 2, 3].map(function (s) { return '<button data-star="' + ci + '" data-s="' + s + '" class="' + (c.w >= s ? "on" : "") + '" aria-label="' + s + ' stars">★</button>'; }).join("") +
        '<button data-star="' + ci + '" data-s="0" style="font-size:13px;color:#888;min-width:30px" aria-label="Skip this category">0</button></span></div>';
    });
    h += '</div><button class="btn" id="done">Done</button>';
    h += '<button class="btn alt" id="newTour">Start a new tour</button>';
    if (S.tours.length > 1) {
      h += '<div class="card"><h3 style="margin-top:0">Your tours</h3>' + S.tours.map(function (x) { return '<div class="yn"><div class="t">' + esc(x.name) + " · " + x.homes.length + ' homes</div>' +
        (x.id === S.active ? '<button class="y on" disabled>Current</button>' : '<button data-tour="' + x.id + '">Open</button><button class="n" data-deltour="' + x.id + '" aria-label="Delete tour">Delete</button>') + "</div>"; }).join("") + "</div>";
    }
    view.innerHTML = h;
    $("#tname").oninput = function () { t.name = this.value; save(); $("#title").textContent = t.name; };
    $("#b0").oninput = function () { t.buyers[0] = this.value || "Buyer 1"; save(); };
    $("#b1").oninput = function () { t.buyers[1] = this.value || "Buyer 2"; save(); };
    $("#musts").oninput = function () { t.musts = this.value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean); save(); };
    view.querySelectorAll("[data-cname]").forEach(function (el) { el.oninput = function () { t.cats[+el.dataset.cname].name = el.value; save(); }; });
    view.querySelectorAll("[data-star]").forEach(function (b) { b.onclick = function () { t.cats[+b.dataset.star].w = +b.dataset.s; save(); var y = scrollY; vSetup(t); scrollTo(0, y); }; });
    view.querySelectorAll("[data-tour]").forEach(function (b) { b.onclick = function () { S.active = b.dataset.tour; save(); go("homes"); }; });
    view.querySelectorAll("[data-deltour]").forEach(function (b) { b.onclick = function () { if (confirm("Delete this tour from this phone?")) { S.tours = S.tours.filter(function (x) { return x.id !== b.dataset.deltour; }); save(); vSetup(tour()); } }; });
    $("#done").onclick = function () { go("homes"); };
    $("#bulkAdd").onclick = function () {
      var added = parseBulk($("#bulk").value).map(function (b) {
        var n = t.homes.reduce(function (m, h) { return Math.max(m, h.n || 0); }, 0) + 1;
        var x = { id: uid(), n: n, addr: b.addr, price: b.price, time: b.time, scores: {}, must: {}, flags: [], verdict: {} };
        t.homes.push(x); return x;
      });
      save(); toast(added.length ? added.length + " homes added" : "No homes found — one per line: time | address | price");
      if (added.length) go("homes");
    };
    $("#newTour").onclick = function () { var n = blankTour("Tour " + (S.tours.length + 1)); n.cats = JSON.parse(JSON.stringify(t.cats)); n.musts = t.musts.slice(); n.buyers = t.buyers.slice(); S.tours.push(n); S.active = n.id; save(); go("setup"); };
  }
  function vSettings(t) {
    setHeader("Settings", "Your details", true);
    var a = S.agent || (S.agent = {});
    var h = '<div class="card"><p class="hint">Shown at the bottom of the screens on this phone, on copied summaries, and passed along inside tour links you share.</p>' +
      '<label class="f" for="an">Agent name</label><input id="an" value="' + esc(a.name) + '">' +
      '<label class="f" for="ab">Brokerage</label><input id="ab" value="' + esc(a.brokerage) + '">' +
      '<label class="f" for="ap">Phone</label><input id="ap" type="tel" value="' + esc(a.phone) + '">' +
      '<label class="f" for="th">Color theme</label><select id="th">' + THEMES.map(function (x) { return "<option" + (x === S.theme ? " selected" : "") + ">" + esc(x) + "</option>"; }).join("") + "</select></div>" +
      '<div class="card"><h3 style="margin-top:0">Install on your phone</h3><p class="hint"><b>iPhone:</b> Safari › Share › Add to Home Screen.<br><b>Android:</b> Chrome › ⋮ menu › Add to Home screen / Install app.<br>After that it opens like an app and works without signal.</p></div>' +
      '<div class="card"><h3 style="margin-top:0">Your data</h3><p class="hint">Everything stays in this browser on this phone. No account, no upload. Clearing your browser data erases it — share a link to keep a copy.</p>' +
      (CFG.demo ? '<button class="btn" id="resetDemo">Reset the demo</button>' : '') +
      '<button class="btn alt" id="wipe" style="border-color:#B9B2A5;color:#6a645a">Erase all tours on this phone</button></div>' +
      '<div class="fair">Tour Day scores homes, not people. Describe the property; for schools, crime or area data, buyers should look up official sources themselves.</div>' + brandLine();
    view.innerHTML = h;
    ["an", "ab", "ap"].forEach(function (id, i) { $("#" + id).oninput = function () { a[["name", "brokerage", "phone"][i]] = this.value; save(); }; });
    $("#th").onchange = function () { S.theme = this.value; save(); document.body.dataset.theme = S.theme; };
    if ($("#resetDemo")) $("#resetDemo").onclick = function () { localStorage.removeItem(KEY); S = load(); toast("Demo reset"); go("homes"); };
    $("#wipe").onclick = function () { if (confirm("Erase every tour on this phone? This can't be undone.")) { localStorage.removeItem(KEY); S = load(); go("homes"); } };
  }

  // ---------- install (Android Chrome offers a prompt; iPhone uses Share › Add to Home Screen) ----------
  var installEvt = null;
  window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); installEvt = e; if (route.name === "homes") render(); });
  function standalone() { return (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone === true; }

  // ---------- boot ----------
  document.querySelectorAll("#tabs button").forEach(function (b) { b.onclick = function () { go(b.dataset.go); }; });
  $("#back").onclick = function () { go(route.name === "home" ? "homes" : "homes"); };
  $("#menu-btn").onclick = function () { go("settings"); };
  if (CFG.demo) $("#demo-banner").hidden = false;
  function checkHash() {
    var m = location.hash.match(/#t=([A-Za-z0-9_-]+)/);
    if (!m) return false;
    try {
      pending = JSON.parse(b64d(m[1]));
      var pt = pending && pending.tour;
      if (!pt || !Array.isArray(pt.homes) || !Array.isArray(pt.buyers) || !Array.isArray(pt.cats) || !Array.isArray(pt.musts)) throw new Error("bad");
      route = { name: "imp" };
      return true;
    } catch (e) { pending = null; toast("That link looks incomplete"); history.replaceState(null, "", location.pathname); return false; }
  }
  try { var saved = JSON.parse(sessionStorage.getItem(KEY + "-route")); if (saved && saved.name && saved.name !== "imp") route = saved; } catch (e) {}
  checkHash();
  window.addEventListener("hashchange", function () { if (checkHash()) render(); });
  render();
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) navigator.serviceWorker.register("sw.js").catch(function () {});
  window.TourDay = { state: function () { return S; }, score: score, mustMiss: mustMiss, parseBulk: parseBulk, tsv: tsv, summary: summaryText, shareLink: shareLink, b64d: b64d };
})();
